# desarrolloPrototipo

Prototipo con base de datos funcionando y con plantillas Bootstrap
No funciona la carga de la fotografía en esta versión.
