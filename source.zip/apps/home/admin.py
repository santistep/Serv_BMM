from django.contrib import admin

# Register your models here.

from apps.home.models import Home

# Register your models here.

admin.site.register(Home)
