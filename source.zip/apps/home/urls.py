from django.urls import path

from .views import redirect_view
from apps.home.views import index, Inicio


urlpatterns = [
    path('redirect/', redirect_view),
    path('', Inicio.as_view(), name='index'),

]