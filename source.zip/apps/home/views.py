from django.shortcuts import render, redirect
from django.views.generic import TemplateView


# Create your views here.

class Inicio(TemplateView):
    template_name = 'home/index.html'


def redirect_view(request):
    response = redirect('/redirect-success/')
    return response


def index(request):
    return render(request, 'home/index.html')
