from django.db import models

# Create your models here.


class Home(models.Model):
    title = "Home"

