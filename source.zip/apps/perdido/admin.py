from django.contrib import admin

# Register your models here.

from apps.perdido.models import Perdido

# Register your models here.

admin.site.register(Perdido)
