from django.apps import AppConfig


class PerdidoConfig(AppConfig):
    name = 'perdido'
