from django.contrib import admin

# Register your models here.

from apps.mascota.models import Mascota

# Register your models here.

admin.site.register(Mascota)
